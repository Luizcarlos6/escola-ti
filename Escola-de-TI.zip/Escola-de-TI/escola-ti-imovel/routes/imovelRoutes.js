const express = require('express');
const router = express.Router();
const imovelController = require('../controllers/imovelController');

// Criar um imóvel
router.post('/', imovelController.createImovel);

// Listar todos os imóveis
router.get('/', imovelController.getAllImoveis);

// Obter um imóvel pelo ID
router.get('/:id', imovelController.getImovelById);

// Atualizar um imóvel pelo ID
router.put('/:id', imovelController.updateImovel);

// Excluir um imóvel pelo ID
router.delete('/:id', imovelController.deleteImovel);

// Adicionar um cômodo ao imóvel
router.post('/:id/comodos', imovelController.addComodo);

// Remover um cômodo do imóvel
router.delete('/:id/comodos/:comodoId', imovelController.removeComodo);

module.exports = router;
