const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('./config/database'); // conexão MongoDB
const imovelRoutes = require('./routes/imovelRoutes');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use('/imoveis', imovelRoutes);

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
