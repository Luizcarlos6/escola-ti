const mongoose = require('mongoose');

const comodoSchema = new mongoose.Schema({
    nome: { type: String, required: true }
});

const imovelSchema = new mongoose.Schema({
    descricao: { type: String, required: true },
    dataCompra: { type: Date, required: true },
    endereco: { type: String, required: true },
    comodos: [comodoSchema]  // Array de cômodos
});

const Imovel = mongoose.model('Imovel', imovelSchema);
module.exports = Imovel;
