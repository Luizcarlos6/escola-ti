const Imovel = require('../models/imovelModel');

// Criar um novo imóvel
exports.createImovel = async (req, res) => {
    try {
        const novoImovel = new Imovel(req.body);
        await novoImovel.save();
        res.status(201).send(novoImovel);
    } catch (error) {
        res.status(400).send(error);
    }
};

// Listar todos os imóveis
exports.getAllImoveis = async (req, res) => {
    try {
        const imoveis = await Imovel.find();
        res.status(200).send(imoveis);
    } catch (error) {
        res.status(500).send(error);
    }
};

// Obter um imóvel por ID
exports.getImovelById = async (req, res) => {
    try {
        const imovel = await Imovel.findById(req.params.id);
        if (!imovel) {
            return res.status(404).send('Imóvel não encontrado');
        }
        res.status(200).send(imovel);
    } catch (error) {
        res.status(500).send(error);
    }
};

// Atualizar um imóvel por ID
exports.updateImovel = async (req, res) => {
    try {
        const imovel = await Imovel.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!imovel) {
            return res.status(404).send('Imóvel não encontrado');
        }
        res.status(200).send(imovel);
    } catch (error) {
        res.status(400).send(error);
    }
};

// Excluir um imóvel por ID
exports.deleteImovel = async (req, res) => {
    try {
        const imovel = await Imovel.findByIdAndDelete(req.params.id);
        if (!imovel) {
            return res.status(404).send('Imóvel não encontrado');
        }
        res.status(200).send('Imóvel excluído com sucesso');
    } catch (error) {
        res.status(500).send(error);
    }
};

// Adicionar um cômodo ao imóvel
exports.addComodo = async (req, res) => {
    try {
        const imovel = await Imovel.findById(req.params.id);
        if (!imovel) {
            return res.status(404).send('Imóvel não encontrado');
        }
        imovel.comodos.push(req.body);
        await imovel.save();
        res.status(200).send(imovel);
    } catch (error) {
        res.status(400).send(error);
    }
};

// Remover um cômodo do imóvel
exports.removeComodo = async (req, res) => {
    try {
        const imovel = await Imovel.findById(req.params.id);
        if (!imovel) {
            return res.status(404).send('Imóvel não encontrado');
        }
        imovel.comodos.id(req.params.comodoId).remove();
        await imovel.save();
        res.status(200).send(imovel);
    } catch (error) {
        res.status(400).send(error);
    }
};
